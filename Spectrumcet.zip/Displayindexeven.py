# Accept a string from user and display only those
# characters which are present at even index number.



string=input('The given string is : ')
print(string[1::2])